
from langchain_ollama import ChatOllama
import json

# Initialize Ollama model
llm = ChatOllama(
    model="llama3.2:3b",
    temperature=0,
    format="json",
    num_predict=1500
)


def generate_test_cases(requirement):

    prompt = f"""
Generate exactly 5 software test cases for this requirement:

{requirement}

Include positive, negative and edge scenarios.

Return JSON only in this format:

{{
    "test_cases": [
        {{
            "title": "Test title",
            "scenario": "Positive",
            "preconditions": "Conditions",
            "steps": "Steps",
            "test_data": "Input",
            "expected_result": "Expected output",
            "priority": "High"
        }}
    ]
}}

Rules:
1. Generate exactly 5 test cases.
2. Use only High, Medium or Low priority.
3. Do not invent unspecified application rules.
4. Keep all fields concise.
5. Every field must contain a string.
6. Return valid JSON without Markdown.
7. Include test_data for every test case.
"""

    try:
        # Get AI response
        response = llm.invoke(prompt)

        content = response.content

        # Convert JSON response
        if not isinstance(content, str):
            raise ValueError("AI response is not text.")

        result = json.loads(content)

        cases = result.get("test_cases")

        if not isinstance(cases, list) or len(cases) != 5:
            raise ValueError("AI did not generate exactly 5 test cases.")

        # Required fields
        required_fields = [
            "title",
            "scenario",
            "preconditions",
            "steps",
            "test_data",
            "expected_result",
            "priority"
        ]

        # Validate each test case
        for case in cases:

            if not isinstance(case, dict):
                raise ValueError("Invalid test case format.")

            for field in required_fields:

                if field not in case or case[field] is None:
                    case[field] = ""

                case[field] = str(case[field]).strip()

                if not case[field]:

                    if field == "test_data":
                        case[field] = "Sample test data"

                    else:
                        raise ValueError(f"Missing field: {field}")

            # Validate priority
            if case["priority"] not in ["High", "Medium", "Low"]:
                case["priority"] = "Medium"

        return cases

    except json.JSONDecodeError as e:
        raise ValueError(f"AI returned invalid JSON: {e}")

    except Exception as e:
        raise ValueError(f"Test case generation failed: {e}")
