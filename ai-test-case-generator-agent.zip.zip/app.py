
import streamlit as st
import pandas as pd
from io import BytesIO
from pypdf import PdfReader

from test_case_generator import generate_test_cases


# Page configuration
st.set_page_config(
    page_title="AI Test Case Generator",
    page_icon="🤖",
    layout="wide"
)


# Custom CSS
st.markdown("""
<style>
.stApp {
    background: linear-gradient(135deg, #e0c3fc, #8ec5fc);
}

.title {
    text-align: center;
    color: #25104a;
    font-size: 38px;
    font-weight: bold;
}

.subtitle {
    text-align: center;
    color: #302050;
    font-size: 18px;
}

</style>
""", unsafe_allow_html=True)


# Project heading
st.markdown(
    '<p class="title">🤖 AI Test Case Generator Agent</p>',
    unsafe_allow_html=True
)

st.markdown(
    '<p class="subtitle">Generate software test cases using Artificial Intelligence</p>',
    unsafe_allow_html=True
)

st.divider()


# Manual requirement input
st.header("📝 Enter Your Software Requirement")

requirement = st.text_area(
    "Describe your software feature:",
    placeholder="Example: A user should be able to login using email and password.",
    height=150
)


# File upload
st.subheader("📂 Or Upload Your Requirement File")

uploaded_file = st.file_uploader(
    "Choose a PDF or TXT file",
    type=["pdf", "txt"]
)

file_requirement = ""

if uploaded_file is not None:
    try:
        file_bytes = uploaded_file.getvalue()

        if uploaded_file.name.lower().endswith(".txt"):
            file_requirement = file_bytes.decode("utf-8-sig")

        elif uploaded_file.name.lower().endswith(".pdf"):
            pdf = PdfReader(BytesIO(file_bytes), strict=False)

            for page in pdf.pages:
                file_requirement += page.extract_text() or ""

        if file_requirement.strip():
            st.success("Requirement file uploaded successfully!")
            st.text_area(
                "Extracted Requirement:",
                value=file_requirement,
                height=120,
                disabled=True
            )
        else:
            st.warning("No readable text found in the uploaded file.")

    except Exception as e:
        st.error(f"Unable to read file: {e}")


# Generate test cases
if st.button("🚀 Generate Test Cases", use_container_width=True):

    final_requirement = (
        file_requirement.strip()
        if uploaded_file is not None
        else requirement.strip()
    )

    if not final_requirement:
        st.warning("Please enter a requirement or upload a valid file.")

    else:
        try:
            with st.spinner("🤖 AI is analyzing your requirement..."):

                test_cases = generate_test_cases(final_requirement)

            if not test_cases:
                st.warning("No test cases were generated.")

            else:
                st.success("Test cases generated successfully!")

                # Convert test cases into DataFrame
                df = pd.DataFrame(test_cases)

                # Project Dashboard
                st.divider()
                st.subheader("📊 Project Dashboard")

                total = len(test_cases)

                high = sum(
                    1 for case in test_cases
                    if case["priority"] == "High"
                )

                medium = sum(
                    1 for case in test_cases
                    if case["priority"] == "Medium"
                )

                low = sum(
                    1 for case in test_cases
                    if case["priority"] == "Low"
                )

                col1, col2, col3, col4 = st.columns(4)

                col1.metric("Total Test Cases", total)
                col2.metric("High Priority", high)
                col3.metric("Medium Priority", medium)
                col4.metric("Low Priority", low)

                # Priority chart
                st.subheader("📈 Test Case Priority Analysis")

                priority_data = pd.DataFrame({
                    "Priority": ["High", "Medium", "Low"],
                    "Count": [high, medium, low]
                })

                st.bar_chart(
                    priority_data.set_index("Priority")
                )

                # Generated test cases
                st.divider()
                st.subheader("📋 Generated Test Cases")

                st.dataframe(
                    df,
                    use_container_width=True,
                    hide_index=True
                )

                # Test case details
                st.subheader("🔍 Test Case Details")

                for index, case in enumerate(test_cases):

                    with st.expander(
                        f"{index + 1}. {case.get('title', 'Test Case')}"
                    ):

                        st.write("**Scenario:**", case.get("scenario", ""))
                        st.write("**Preconditions:**", case.get("preconditions", ""))
                        st.write("**Steps:**", case.get("steps", ""))
                        st.write("**Test Data:**", case.get("test_data", ""))
                        st.write("**Expected Result:**", case.get("expected_result", ""))
                        st.write("**Priority:**", case.get("priority", ""))

                # CSV download
                csv = df.to_csv(index=False).encode("utf-8")

                st.download_button(
                    label="📥 Download Test Cases as CSV",
                    data=csv,
                    file_name="test_cases.csv",
                    mime="text/csv"
                )

                # Excel download
                excel_data = BytesIO()

                with pd.ExcelWriter(
                    excel_data,
                    engine="openpyxl"
                ) as writer:

                    df.to_excel(
                        writer,
                        index=False,
                        sheet_name="Test Cases"
                    )

                st.download_button(
                    label="📥 Download Test Cases as Excel",
                    data=excel_data.getvalue(),
                    file_name="test_cases.xlsx",
                    mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                )

        except Exception as e:
            st.error(f"Something went wrong: {e}")


# Footer
st.divider()

st.markdown(
    "<center>AI Test Case Generator Agent | Internship Project</center>",
    unsafe_allow_html=True
)
